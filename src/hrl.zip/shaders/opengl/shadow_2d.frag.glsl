#version 330 core

void main()
{
    // Depth is written automatically by the rasterizer.
}
